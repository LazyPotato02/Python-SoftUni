Os: Fedora 37
Resolution: 1920:1080
