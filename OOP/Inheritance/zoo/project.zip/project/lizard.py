from .reptile import Reptile


class Lizard(Reptile):

    def __init__(self, *args):
        super().__init__(*args)
