from .mammal import Mammal


class Bear(Mammal):
    def __init__(self, *args):
        super().__init__(*args)
