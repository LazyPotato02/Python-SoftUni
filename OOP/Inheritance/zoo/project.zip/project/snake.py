from .reptile import Reptile


class Snake(Reptile):
    def __init__(self, *args):
        super().__init__(*args)
