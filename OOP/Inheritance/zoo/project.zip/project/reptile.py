from .animal import Animal


class Reptile(Animal):

    def __init__(self, *args):
        super().__init__(*args)
