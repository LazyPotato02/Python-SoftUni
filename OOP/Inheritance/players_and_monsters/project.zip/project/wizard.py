from .hero import Hero

class Wizard(Hero):
    def __init__(self, *args):
        super().__init__(*args)

