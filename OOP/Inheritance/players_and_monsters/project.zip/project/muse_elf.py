from .elf import Elf

class MuseElf(Elf):
    def __init__(self, *args):
        super().__init__(*args)

