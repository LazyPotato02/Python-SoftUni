from .hero import Hero

class Knight(Hero):
    def __init__(self, *args):
        super().__init__(*args)

