from .wizard import Wizard

class DarkWizard(Wizard):
    def __init__(self, *args):
        super().__init__(*args)

