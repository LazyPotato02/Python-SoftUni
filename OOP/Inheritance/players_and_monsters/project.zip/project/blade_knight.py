from .dark_knight import DarkKnight

class BladeKnight(DarkKnight):
    def __init__(self, *args):
        super().__init__(*args)

