from .dark_wizard import DarkWizard

class SoulMaster(DarkWizard):
    def __init__(self, *args):
        super().__init__(*args)

