from .motorcycle import Motorcycle

class CrossMotorcycle(Motorcycle):

    def __init__(self, *args) -> None:
        super().__init__(*args)
    