// TODO
function attachEvents() {
  
}

attachEvents();
